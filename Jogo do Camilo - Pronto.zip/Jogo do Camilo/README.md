# 003_Sliding_Puzzle_Godot
A simple sliding puzzle game made with Godot Engine 4.

Each tile has a number from 1 to 15. The tiles are randomly shuffled at the start of the game and you should order the tiles as in the following screenshot:

You can watch the video on how I made it here:

https://youtu.be/aODh7LNiEbI


<img src="https://user-images.githubusercontent.com/122635521/230923582-b278098f-17cf-46ed-9683-900b39a416c6.png" width=400px>

